package com.example.examenLP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenLpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenLpApplication.class, args);
	}

}
