package com.example.examenLP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenLpApplicationTests {

	@Test
	void contextLoads() {
	}

}
